package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class ProdutosActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var rvProdutos: RecyclerView
    private lateinit var tvNenhumProduto: TextView
    private lateinit var adapter: ProdutoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_produtos)

        dbHelper = DatabaseHelper(this)

        val btnVoltar = findViewById<ImageButton>(R.id.btnVoltarProdutos)
        val btnCadastrarProduto = findViewById<MaterialButton>(R.id.btnCadastrarProduto)
        rvProdutos = findViewById(R.id.rvProdutos)
        tvNenhumProduto = findViewById(R.id.tvNenhumProduto)

        btnVoltar.setOnClickListener {
            finish()
        }

        btnCadastrarProduto.setOnClickListener {
            val intent = Intent(this, FormProdutoActivity::class.java)
            startActivity(intent)
        }

        rvProdutos.layoutManager = LinearLayoutManager(this)

        adapter = ProdutoAdapter(
            produtosList = emptyList(),
            onEditClick = { produto ->
                val intent = Intent(this, FormProdutoActivity::class.java)
                intent.putExtra("PRODUTO_ID", produto.id)
                startActivity(intent)
            },
            onDeleteClick = { produto ->
                val excluido = dbHelper.deleteProduct(produto.id)
                if (excluido) {
                    Toast.makeText(this, "Produto excluído!", Toast.LENGTH_SHORT).show()
                    loadProdutos()
                } else {
                    Toast.makeText(this, "Erro ao excluir", Toast.LENGTH_SHORT).show()
                }
            }
        )
        rvProdutos.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        loadProdutos()
    }

    private fun loadProdutos() {
        val lista = dbHelper.getAllProducts()
        if (lista.isEmpty()) {
            tvNenhumProduto.visibility = View.VISIBLE
            rvProdutos.visibility = View.GONE
        } else {
            tvNenhumProduto.visibility = View.GONE
            rvProdutos.visibility = View.VISIBLE
            adapter.updateList(lista)
        }
    }
}