package com.example.zenestoques

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProdutoAdapter(
    private var produtosList: List<ProductModel>,
    private val onEditClick: (ProductModel) -> Unit,
    private val onDeleteClick: (ProductModel) -> Unit
) : RecyclerView.Adapter<ProdutoAdapter.ProdutoViewHolder>() {

    class ProdutoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNomeProduto: TextView = itemView.findViewById(R.id.tvNomeProduto)
        val tvCodigoProduto: TextView = itemView.findViewById(R.id.tvCodigoProduto)
        val tvPrecoCompra: TextView = itemView.findViewById(R.id.tvPrecoCompra)
        val tvPrecoVenda: TextView = itemView.findViewById(R.id.tvPrecoVenda)
        val btnEditarProduto: ImageButton = itemView.findViewById(R.id.btnEditarProduto)
        val btnExcluirProduto: ImageButton = itemView.findViewById(R.id.btnExcluirProduto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProdutoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_produto, parent, false)
        return ProdutoViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProdutoViewHolder, position: Int) {
        val produto = produtosList[position]
        holder.tvNomeProduto.text = produto.nome
        holder.tvCodigoProduto.text = "Código: ${produto.codigo} | Num: ${produto.numero}"
        holder.tvPrecoCompra.text = "R$ ${String.format("%.2f", produto.precoCompra)}"
        holder.tvPrecoVenda.text = "R$ ${String.format("%.2f", produto.precoVenda)}"

        holder.btnEditarProduto.setOnClickListener {
            onEditClick(produto)
        }

        holder.btnExcluirProduto.setOnClickListener {
            onDeleteClick(produto)
        }
    }

    override fun getItemCount(): Int = produtosList.size

    fun updateList(newList: List<ProductModel>) {
        produtosList = newList
        notifyDataSetChanged()
    }
}