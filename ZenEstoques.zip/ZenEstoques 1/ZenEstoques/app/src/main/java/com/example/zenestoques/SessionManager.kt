package com.example.zenestoques

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val pref: SharedPreferences = context.getSharedPreferences("ZenEstoquesSession", Context.MODE_PRIVATE)

    fun saveUserEmail(email: String) {
        pref.edit().putString("LOGGED_USER_EMAIL", email).apply()
    }

    fun getLoggedUserEmail(): String? {
        return pref.getString("LOGGED_USER_EMAIL", null)
    }

    fun logout() {
        pref.edit().clear().apply()
    }
}
