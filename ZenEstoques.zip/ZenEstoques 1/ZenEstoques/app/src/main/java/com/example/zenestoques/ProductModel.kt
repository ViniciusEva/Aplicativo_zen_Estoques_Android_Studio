package com.example.zenestoques

data class ProductModel(
    val id: Int = 0,
    val nome: String,
    val numero: String,
    val codigo: String,
    val precoCompra: Double,
    val precoVenda: Double
)