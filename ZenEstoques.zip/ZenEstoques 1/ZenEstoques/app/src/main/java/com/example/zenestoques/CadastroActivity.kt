package com.example.zenestoques

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class CadastroActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        dbHelper = DatabaseHelper(this)

        // Mapeando os componentes visuais do layout
        val btnVoltar = findViewById<ImageButton>(R.id.btnVoltar)
        val etNome = findViewById<EditText>(R.id.etNome)
        val etEmail = findViewById<EditText>(R.id.etEmailCadastro)
        val etTelefone = findViewById<EditText>(R.id.etTelefone)
        val etEmpresa = findViewById<EditText>(R.id.etEmpresa)
        val etSenha = findViewById<EditText>(R.id.etSenhaCadastro)
        val etConfirmarSenha = findViewById<EditText>(R.id.etConfirmarSenha)
        val btnConfirmar = findViewById<MaterialButton>(R.id.btnConfirmarCadastro)

        // Ação do botão voltar (encerra esta tela e volta para a MainActivity)
        btnVoltar.setOnClickListener {
            finish()
        }

        // Ação do botão confirmar cadastro
        btnConfirmar.setOnClickListener {
            val nome = etNome.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val telefone = etTelefone.text.toString().trim()
            val empresa = etEmpresa.text.toString().trim()
            val senha = etSenha.text.toString().trim()
            val confirmarSenha = etConfirmarSenha.text.toString().trim()

            // 1. Validação de campos vazios
            if (nome.isEmpty() || email.isEmpty() || telefone.isEmpty() ||
                empresa.isEmpty() || senha.isEmpty() || confirmarSenha.isEmpty()
            ) {
                Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Para a execução aqui se faltar dado
            }

            // 2. Validação das senhas (verificar se são iguais)
            if (senha != confirmarSenha) {
                Toast.makeText(this, "As senhas não coincidem. Tente novamente.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 3. Salvar no banco de dados SQLite
            val resultado = dbHelper.addUser(
                email = email,
                pass = senha,
                nome = nome,
                telefone = telefone,
                empresa = empresa
            )

            if (resultado > -1) {
                SessionManager(this).saveUserEmail(email)
                Toast.makeText(this, "Conta criada com sucesso!", Toast.LENGTH_LONG).show()
                finish()
            } else {
                // Erro ao inserir no banco
                Toast.makeText(this, "Erro ao criar conta. Tente novamente.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
