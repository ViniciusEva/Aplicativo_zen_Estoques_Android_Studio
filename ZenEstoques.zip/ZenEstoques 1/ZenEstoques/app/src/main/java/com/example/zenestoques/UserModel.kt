package com.example.zenestoques

data class UserModel(
    val nome: String,
    val email: String,
    val telefone: String,
    val empresa: String = "",
    val cpf: String = ""
)
