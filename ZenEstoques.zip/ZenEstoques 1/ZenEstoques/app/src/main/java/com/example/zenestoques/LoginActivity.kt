package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DatabaseHelper(this)

        val btnVoltar = findViewById<ImageButton>(R.id.btnVoltarLogin)
        val etEmail = findViewById<EditText>(R.id.etEmailLogin)
        val etSenha = findViewById<EditText>(R.id.etSenhaLogin)
        val btnEntrar = findViewById<Button>(R.id.btnEntrar)

        btnVoltar.setOnClickListener {
            finish()
        }

        btnEntrar.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val senha = etSenha.text.toString().trim()

            // Validação básica para não enviar campos vazios
            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Consulta ao banco de dados SQLite
            val loginSucesso = dbHelper.checkUser(email, senha)
            if (loginSucesso) {
                SessionManager(this).saveUserEmail(email)
                Toast.makeText(this, "Sessão iniciada com sucesso!", Toast.LENGTH_SHORT).show()

                // Iniciar a HomeActivity
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)

                // Opcional: Chamar finish() para impedir que o utilizador volte ao login ao clicar na seta "Voltar" do telemóvel
                finish()
            } else {
                Toast.makeText(this, "E-mail ou senha incorretos.", Toast.LENGTH_LONG).show()
            }
        }
    }
}