package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout

import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val btnToggleMenu = findViewById<ImageButton>(R.id.btnToggleMenu)
        val llMenuContent = findViewById<LinearLayout>(R.id.llMenuContent)

        btnToggleMenu.setOnClickListener {
            if (llMenuContent.visibility == View.VISIBLE) {
                llMenuContent.visibility = View.GONE
            } else {
                llMenuContent.visibility = View.VISIBLE
            }
        }


        val btnAjudaMenu = findViewById<MaterialButton>(R.id.btnAjudaMenu)
        val btnHomeMenu = findViewById<MaterialButton>(R.id.btnHomeMenu)
        val btnDashboardMenu = findViewById<MaterialButton>(R.id.btnDashboardMenu)
        val btnProdutosMenu = findViewById<MaterialButton>(R.id.btnProdutosMenu)
        val ivPerfilMenuTop = findViewById<ImageView>(R.id.ivPerfilMenuTop)
        val ivPerfilMenu = findViewById<ImageView>(R.id.ivPerfilMenu)

        val abrirPerfil = {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }

        ivPerfilMenuTop?.setOnClickListener { abrirPerfil() }
        ivPerfilMenu?.setOnClickListener { abrirPerfil() }

        btnHomeMenu.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }

        btnDashboardMenu.setOnClickListener {
            // Já estamos no Dashboard
            llMenuContent.visibility = View.GONE
        }
        
        btnProdutosMenu.setOnClickListener {
            val intent = Intent(this, ProdutosActivity::class.java)
            startActivity(intent)
        }

        btnAjudaMenu.setOnClickListener {
            val intent = Intent(this, AjudaActivity::class.java)
            startActivity(intent)
        }
    }
}