package com.example.zenestoques

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class EditarPerfilActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_perfil)

        dbHelper = DatabaseHelper(this)
        sessionManager = SessionManager(this)

        val btnVoltar = findViewById<ImageButton>(R.id.btnVoltarEditarPerfil)
        val etNomeCompleto = findViewById<EditText>(R.id.etNomeCompleto)
        val etEmail = findViewById<EditText>(R.id.etEmailEditar)
        val etTelefone = findViewById<EditText>(R.id.etTelefoneEditar)
        val etCpf = findViewById<EditText>(R.id.etCpfEditar)
        val layoutAlterarSenha = findViewById<RelativeLayout>(R.id.layoutAlterarSenha)
        val btnAlterarSenhaArrow = findViewById<ImageButton>(R.id.btnAlterarSenhaArrow)
        val btnSalvar = findViewById<MaterialButton>(R.id.btnSalvarAlteracoes)
        val btnCancelar = findViewById<MaterialButton>(R.id.btnCancelarEditarPerfil)

        // Preencher com os dados do usuário logado
        val loggedEmail = sessionManager.getLoggedUserEmail()
        if (loggedEmail != null) {
            val user = dbHelper.getUserData(loggedEmail)
            if (user != null) {
                if (user.nome.isNotEmpty()) etNomeCompleto.setText(user.nome)
                etEmail.setText(user.email)
                if (user.telefone.isNotEmpty()) etTelefone.setText(user.telefone)
                if (user.cpf.isNotEmpty()) etCpf.setText(user.cpf)
            } else {
                etEmail.setText(loggedEmail)
            }
        }

        btnVoltar.setOnClickListener {
            finish()
        }

        btnCancelar.setOnClickListener {
            finish()
        }

        val acaoAlterarSenha = {
            Toast.makeText(this, "A abrir alteração de senha...", Toast.LENGTH_SHORT).show()
        }

        layoutAlterarSenha.setOnClickListener { acaoAlterarSenha() }
        btnAlterarSenhaArrow.setOnClickListener { acaoAlterarSenha() }

        btnSalvar.setOnClickListener {
            val nome = etNomeCompleto.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val telefone = etTelefone.text.toString().trim()
            val cpf = etCpf.text.toString().trim()

            if (email.isEmpty()) {
                Toast.makeText(this, "Por favor, preencha o e-mail.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (loggedEmail != null) {
                dbHelper.updateUserData(loggedEmail, nome, telefone, cpf)
            }

            Toast.makeText(this, "Alterações salvas com sucesso!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}