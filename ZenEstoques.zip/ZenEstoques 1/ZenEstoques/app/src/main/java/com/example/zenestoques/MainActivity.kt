package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import android.util.Log

class MainActivity : AppCompatActivity() {

    // Inicializando o banco de dados
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        // Chama a função que fará o CRUD silencioso no Logcat
        testarCRUDLogcat()

        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnCadastro = findViewById<Button>(R.id.btnCadastro)

        // Direciona para a tela de Login
        btnLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        // Direciona para a tela de Cadastro
        btnCadastro.setOnClickListener {
            val intent = Intent(this, CadastroActivity::class.java)
            startActivity(intent)
        }
    }

    private fun testarCRUDLogcat() {
        val tag = "ZenEstoques_CRUD"
        Log.d(tag, "--- INICIANDO TESTE CRUD ---")

        // 1. CREATE (Criar)
        val novoId = dbHelper.addUser("admin@zenestoques.com", "senha123")
        Log.d(tag, "C - Usuário inserido com ID: $novoId")

        // 2. READ (Ler)
        val usuarios = dbHelper.getAllUsers()
        Log.d(tag, "R - Lista de usuários no banco: $usuarios")

        // 3. UPDATE (Atualizar)
        val atualizado = dbHelper.updateUser(novoId.toInt(), "novaSenhaSegura456")
        Log.d(tag, "U - Senha do ID $novoId atualizada? $atualizado")

        // 4. DELETE (Deletar)
        // Descomente as duas linhas abaixo se quiser testar a exclusão e ver a lista vazia depois
        /*
        val deletado = dbHelper.deleteUser(novoId.toInt())
        Log.d(tag, "D - Usuário ID $novoId deletado? $deletado")
        Log.d(tag, "Lista final: ${dbHelper.getAllUsers()}")
        */

        Log.d(tag, "--- FIM DO TESTE CRUD ---")
    }
}