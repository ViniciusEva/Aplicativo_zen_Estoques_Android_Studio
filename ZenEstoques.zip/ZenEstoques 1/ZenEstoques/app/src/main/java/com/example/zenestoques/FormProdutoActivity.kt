package com.example.zenestoques

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class FormProdutoActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private var produtoId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_produto)

        dbHelper = DatabaseHelper(this)

        val btnVoltar = findViewById<ImageButton>(R.id.btnVoltarFormProduto)
        val tvTituloForm = findViewById<TextView>(R.id.tvTituloForm)
        val etNome = findViewById<EditText>(R.id.etNomeProduto)
        val etNumero = findViewById<EditText>(R.id.etNumeroProduto)
        val etCodigo = findViewById<EditText>(R.id.etCodigoProduto)
        val etPrecoCompra = findViewById<EditText>(R.id.etPrecoCompra)
        val etPrecoVenda = findViewById<EditText>(R.id.etPrecoVenda)
        val btnSalvar = findViewById<MaterialButton>(R.id.btnSalvarProduto)

        produtoId = intent.getIntExtra("PRODUTO_ID", -1)

        if (produtoId != -1) {
            tvTituloForm.text = "Editar Produto"
            carregarDadosProduto(produtoId, etNome, etNumero, etCodigo, etPrecoCompra, etPrecoVenda)
        }

        btnVoltar.setOnClickListener {
            finish()
        }

        btnSalvar.setOnClickListener {
            val nome = etNome.text.toString().trim()
            val numero = etNumero.text.toString().trim()
            val codigo = etCodigo.text.toString().trim()
            val precoCompraStr = etPrecoCompra.text.toString().trim()
            val precoVendaStr = etPrecoVenda.text.toString().trim()

            if (nome.isEmpty() || numero.isEmpty() || codigo.isEmpty() || precoCompraStr.isEmpty() || precoVendaStr.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val precoCompra = precoCompraStr.toDoubleOrNull() ?: 0.0
            val precoVenda = precoVendaStr.toDoubleOrNull() ?: 0.0

            if (produtoId == -1) {
                // Cadastrar novo
                val idInserido = dbHelper.addProduct(nome, numero, codigo, precoCompra, precoVenda)
                if (idInserido > -1) {
                    Toast.makeText(this, "Produto salvo com sucesso!", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "Erro ao salvar", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Editar existente
                val atualizado = dbHelper.updateProduct(produtoId, nome, numero, codigo, precoCompra, precoVenda)
                if (atualizado) {
                    Toast.makeText(this, "Produto atualizado!", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "Erro ao atualizar", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun carregarDadosProduto(
        id: Int,
        etNome: EditText,
        etNumero: EditText,
        etCodigo: EditText,
        etPrecoCompra: EditText,
        etPrecoVenda: EditText
    ) {
        // Para simplificar, vou buscar todos e filtrar pelo ID (em produção o ideal seria ter um getUserById no dbHelper)
        val produtos = dbHelper.getAllProducts()
        val produto = produtos.find { it.id == id }

        if (produto != null) {
            etNome.setText(produto.nome)
            etNumero.setText(produto.numero)
            etCodigo.setText(produto.codigo)
            etPrecoCompra.setText(produto.precoCompra.toString())
            etPrecoVenda.setText(produto.precoVenda.toString())
        }
    }
}