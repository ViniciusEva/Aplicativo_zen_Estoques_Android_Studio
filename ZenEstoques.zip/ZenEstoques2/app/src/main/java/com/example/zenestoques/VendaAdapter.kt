package com.example.zenestoques

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class VendaAdapter(
    private var meVendasList: List<VendaModel>,
    private val onDeleteClick: (VendaModel) -> Unit
) : RecyclerView.Adapter<VendaAdapter.VendaViewHolder>() {

    class VendaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvProdutoNome: TextView = itemView.findViewById(R.id.tvVendaProdutoNome)
        val tvDataQtd: TextView = itemView.findViewById(R.id.tvVendaDataQtd)
        val tvValorTotal: TextView = itemView.findViewById(R.id.tvVendaValorTotal)
        val btnExcluir: ImageButton = itemView.findViewById(R.id.btnExcluirVenda)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VendaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_venda, parent, false)
        return VendaViewHolder(view)
    }

    override fun onBindViewHolder(holder: VendaViewHolder, position: Int) {
        val venda = meVendasList[position]
        holder.tvProdutoNome.text = venda.produtoNome
        holder.tvDataQtd.text = "Qtd: ${venda.quantidade} | Data: ${venda.dataVenda}"
        holder.tvValorTotal.text = String.format(Locale.getDefault(), "R$ %.2f", venda.valorTotal)

        holder.btnExcluir.setOnClickListener {
            onDeleteClick(venda)
        }
    }

    override fun getItemCount(): Int = meVendasList.size

    fun updateList(newList: List<VendaModel>) {
        meVendasList = newList
        notifyDataSetChanged()
    }
}
