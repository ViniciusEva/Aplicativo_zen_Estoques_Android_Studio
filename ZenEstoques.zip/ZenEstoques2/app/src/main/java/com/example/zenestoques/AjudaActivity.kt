package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class AjudaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ajuda)

        val btnToggleMenu = findViewById<ImageButton>(R.id.btnToggleMenu)
        val llMenuContent = findViewById<LinearLayout>(R.id.llMenuContent)

        btnToggleMenu?.setOnClickListener {
            if (llMenuContent?.visibility == View.VISIBLE) {
                llMenuContent.visibility = View.GONE
            } else {
                llMenuContent?.visibility = View.VISIBLE
            }
        }

        val btnHomeMenu = findViewById<MaterialButton>(R.id.btnHomeMenu)
        val btnDashboardMenu = findViewById<MaterialButton>(R.id.btnDashboardMenu)
        val btnProdutosMenu = findViewById<MaterialButton>(R.id.btnProdutosMenu)
        val btnVendasMenu = findViewById<MaterialButton>(R.id.btnVendasMenu)
        val ivPerfilMenuTop = findViewById<ImageView>(R.id.ivPerfilMenuTop)
        val ivPerfilMenu = findViewById<ImageView>(R.id.ivPerfilMenu)
        val cardContato = findViewById<LinearLayout>(R.id.cardContato)
        val cardProblema = findViewById<LinearLayout>(R.id.cardProblema)
        val cardAvaliacao = findViewById<LinearLayout>(R.id.cardAvaliacao)

        val abrirPerfil = {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }

        ivPerfilMenuTop?.setOnClickListener { abrirPerfil() }
        ivPerfilMenu?.setOnClickListener { abrirPerfil() }

        btnHomeMenu?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        btnDashboardMenu?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        btnProdutosMenu?.setOnClickListener {
            val intent = Intent(this, ProdutosActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnVendasMenu?.setOnClickListener {
            val intent = Intent(this, VendasActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Simula a abertura de um contato ou e-mail
        cardContato.setOnClickListener {
            Toast.makeText(this, "Redirecionando para o Contato...", Toast.LENGTH_SHORT).show()
        }

        // Simula o relato de um problema
        cardProblema.setOnClickListener {
            Toast.makeText(this, "Abrindo formulário de problema...", Toast.LENGTH_SHORT).show()
        }

        // Simula o redirecionamento para a loja de aplicativos
        cardAvaliacao.setOnClickListener {
            Toast.makeText(this, "Redirecionando para a Play Store...", Toast.LENGTH_SHORT).show()
        }
    }
}