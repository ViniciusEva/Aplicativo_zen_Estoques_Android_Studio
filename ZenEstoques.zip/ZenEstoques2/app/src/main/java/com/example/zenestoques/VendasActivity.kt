package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VendasActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var spinnerProdutos: Spinner
    private lateinit var etQuantidade: EditText
    private lateinit var tvValorTotalCalculado: TextView
    private lateinit var btnRegistrarVenda: MaterialButton
    private lateinit var rvVendas: RecyclerView
    private lateinit var tvNenhumaVenda: TextView
    private lateinit var vendaAdapter: VendaAdapter

    private var meProdutosList: List<ProductModel> = emptyList()
    private var selectedProduct: ProductModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vendas)

        dbHelper = DatabaseHelper(this)

        setupMenuNavigation()

        spinnerProdutos = findViewById(R.id.spinnerProdutos)
        etQuantidade = findViewById(R.id.etQuantidadeVenda)
        tvValorTotalCalculado = findViewById(R.id.tvValorTotalCalculado)
        btnRegistrarVenda = findViewById(R.id.btnRegistrarVenda)
        rvVendas = findViewById(R.id.rvVendas)
        tvNenhumaVenda = findViewById(R.id.tvNenhumaVenda)

        rvVendas.layoutManager = LinearLayoutManager(this)
        vendaAdapter = VendaAdapter(emptyList()) { venda ->
            val excluido = dbHelper.deleteVenda(venda.id)
            if (excluido) {
                Toast.makeText(this, "Venda removida!", Toast.LENGTH_SHORT).show()
                carregarVendas()
            } else {
                Toast.makeText(this, "Erro ao remover venda", Toast.LENGTH_SHORT).show()
            }
        }
        rvVendas.adapter = vendaAdapter

        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        carregarProdutos()
        carregarVendas()
    }

    private fun setupMenuNavigation() {
        val btnToggleMenu = findViewById<ImageButton>(R.id.btnToggleMenu)
        val llMenuContent = findViewById<LinearLayout>(R.id.llMenuContent)

        btnToggleMenu?.setOnClickListener {
            if (llMenuContent?.visibility == View.VISIBLE) {
                llMenuContent.visibility = View.GONE
            } else {
                llMenuContent?.visibility = View.VISIBLE
            }
        }

        val btnHomeMenu = findViewById<MaterialButton>(R.id.btnHomeMenu)
        val btnDashboardMenu = findViewById<MaterialButton>(R.id.btnDashboardMenu)
        val btnProdutosMenu = findViewById<MaterialButton>(R.id.btnProdutosMenu)
        val btnVendasMenu = findViewById<MaterialButton>(R.id.btnVendasMenu)
        val btnAjudaMenu = findViewById<MaterialButton>(R.id.btnAjudaMenu)
        val ivPerfilMenuTop = findViewById<ImageView>(R.id.ivPerfilMenuTop)
        val ivPerfilMenu = findViewById<ImageView>(R.id.ivPerfilMenu)

        val abrirPerfil = {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }

        ivPerfilMenuTop?.setOnClickListener { abrirPerfil() }
        ivPerfilMenu?.setOnClickListener { abrirPerfil() }

        btnHomeMenu?.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        btnDashboardMenu?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        btnProdutosMenu?.setOnClickListener {
            val intent = Intent(this, ProdutosActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnVendasMenu?.setOnClickListener {
            llMenuContent?.visibility = View.GONE
        }

        btnAjudaMenu?.setOnClickListener {
            val intent = Intent(this, AjudaActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun carregarProdutos() {
        meProdutosList = dbHelper.getAllProducts()
        if (meProdutosList.isEmpty()) {
            val emptyAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("Nenhum produto cadastrado"))
            emptyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerProdutos.adapter = emptyAdapter
            selectedProduct = null
            tvValorTotalCalculado.text = "R$ 0,00"
        } else {
            val nomesProdutos = meProdutosList.map { "${it.nome} (R$ ${String.format(Locale.getDefault(), "%.2f", it.precoVenda)})" }
            val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, nomesProdutos)
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerProdutos.adapter = spinnerAdapter
            if (meProdutosList.isNotEmpty()) {
                selectedProduct = meProdutosList[0]
                atualizarValorTotal()
            }
        }
    }

    private fun carregarVendas() {
        val vendas = dbHelper.getAllVendas()
        if (vendas.isEmpty()) {
            tvNenhumaVenda.visibility = View.VISIBLE
            rvVendas.visibility = View.GONE
        } else {
            tvNenhumaVenda.visibility = View.GONE
            rvVendas.visibility = View.VISIBLE
            vendaAdapter.updateList(vendas)
        }
    }

    private fun setupListeners() {
        spinnerProdutos.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (meProdutosList.isNotEmpty() && position in meProdutosList.indices) {
                    selectedProduct = meProdutosList[position]
                    atualizarValorTotal()
                } else {
                    selectedProduct = null
                    tvValorTotalCalculado.text = "R$ 0,00"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedProduct = null
                tvValorTotalCalculado.text = "R$ 0,00"
            }
        }

        etQuantidade.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                atualizarValorTotal()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        btnRegistrarVenda.setOnClickListener {
            registrarVenda()
        }
    }

    private fun atualizarValorTotal() {
        val prod = selectedProduct ?: return
        val qtdStr = etQuantidade.text.toString().trim()
        val qtd = qtdStr.toIntOrNull() ?: 0
        val total = prod.precoVenda * qtd
        tvValorTotalCalculado.text = String.format(Locale.getDefault(), "R$ %.2f", total)
    }

    private fun registrarVenda() {
        val prod = selectedProduct
        if (prod == null) {
            Toast.makeText(this, "Por favor, cadastre um produto primeiro!", Toast.LENGTH_LONG).show()
            return
        }

        val qtdStr = etQuantidade.text.toString().trim()
        val qtd = qtdStr.toIntOrNull()

        if (qtd == null || qtd <= 0) {
            Toast.makeText(this, "Informe uma quantidade válida", Toast.LENGTH_SHORT).show()
            return
        }

        // Verificar estoque disponível
        val estoqueAtual = prod.numero.toIntOrNull() ?: 0
        if (qtd > estoqueAtual) {
            Toast.makeText(this, "Estoque insuficiente! Disponível: $estoqueAtual", Toast.LENGTH_LONG).show()
            return
        }

        val valorTotal = prod.precoVenda * qtd
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dataVenda = dateFormat.format(Date())

        val idVenda = dbHelper.addVenda(prod.nome, qtd, valorTotal, dataVenda)
        if (idVenda > -1) {
            // Atualiza (abate) o estoque do produto
            val novoEstoque = (estoqueAtual - qtd).toString()
            dbHelper.updateProduct(prod.id, prod.nome, novoEstoque, prod.codigo, prod.precoCompra, prod.precoVenda)

            Toast.makeText(this, "Venda registrada com sucesso!", Toast.LENGTH_SHORT).show()
            etQuantidade.setText("1")
            carregarProdutos()
            carregarVendas()
        } else {
            Toast.makeText(this, "Erro ao registrar venda", Toast.LENGTH_SHORT).show()
        }
    }
}
