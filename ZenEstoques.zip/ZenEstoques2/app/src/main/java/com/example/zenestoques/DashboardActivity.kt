package com.example.zenestoques

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.util.Locale

class DashboardActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var tvTotalVendasDash: TextView
    private lateinit var tvTotalLucroDash: TextView
    private lateinit var tvRoiDash: TextView
    private lateinit var llTopProdutosContainer: LinearLayout
    private lateinit var llAlertasContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        dbHelper = DatabaseHelper(this)

        tvTotalVendasDash = findViewById(R.id.tvTotalVendasDash)
        tvTotalLucroDash = findViewById(R.id.tvTotalLucroDash)
        tvRoiDash = findViewById(R.id.tvRoiDash)
        llTopProdutosContainer = findViewById(R.id.llTopProdutosContainer)
        llAlertasContainer = findViewById(R.id.llAlertasContainer)

        setupMenuNavigation()
    }

    override fun onResume() {
        super.onResume()
        atualizarDadosDashboard()
    }

    private fun setupMenuNavigation() {
        val btnToggleMenu = findViewById<ImageButton>(R.id.btnToggleMenu)
        val llMenuContent = findViewById<LinearLayout>(R.id.llMenuContent)

        btnToggleMenu.setOnClickListener {
            if (llMenuContent.visibility == View.VISIBLE) {
                llMenuContent.visibility = View.GONE
            } else {
                llMenuContent.visibility = View.VISIBLE
            }
        }

        val btnAjudaMenu = findViewById<MaterialButton>(R.id.btnAjudaMenu)
        val btnHomeMenu = findViewById<MaterialButton>(R.id.btnHomeMenu)
        val btnDashboardMenu = findViewById<MaterialButton>(R.id.btnDashboardMenu)
        val btnProdutosMenu = findViewById<MaterialButton>(R.id.btnProdutosMenu)
        val btnVendasMenu = findViewById<MaterialButton>(R.id.btnVendasMenu)
        val ivPerfilMenuTop = findViewById<ImageView>(R.id.ivPerfilMenuTop)
        val ivPerfilMenu = findViewById<ImageView>(R.id.ivPerfilMenu)

        val abrirPerfil = {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }

        ivPerfilMenuTop?.setOnClickListener { abrirPerfil() }
        ivPerfilMenu?.setOnClickListener { abrirPerfil() }

        btnHomeMenu.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        btnDashboardMenu.setOnClickListener {
            llMenuContent.visibility = View.GONE
        }

        btnProdutosMenu.setOnClickListener {
            val intent = Intent(this, ProdutosActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnVendasMenu?.setOnClickListener {
            val intent = Intent(this, VendasActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnAjudaMenu.setOnClickListener {
            val intent = Intent(this, AjudaActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun atualizarDadosDashboard() {
        val vendas = dbHelper.getAllVendas()
        val produtos = dbHelper.getAllProducts()

        // 1. Resumo Financeiro
        val totalVendas = vendas.sumOf { it.valorTotal }
        val produtosMap = produtos.associateBy { it.nome }

        var totalLucro = 0.0
        for (venda in vendas) {
            val prod = produtosMap[venda.produtoNome]
            if (prod != null) {
                totalLucro += (prod.precoVenda - prod.precoCompra) * venda.quantidade
            } else {
                totalLucro += venda.valorTotal * 0.3
            }
        }

        val totalCusto = totalVendas - totalLucro
        val roi = if (totalCusto > 0) (totalLucro / totalCusto) * 100.0 else 0.0

        tvTotalVendasDash.text = String.format(Locale.getDefault(), "R$ %.2f", totalVendas)
        tvTotalLucroDash.text = String.format(Locale.getDefault(), "R$ %.2f", totalLucro)
        tvRoiDash.text = String.format(Locale.getDefault(), "%.1f%%", roi)

        // 2. Produtos Mais Vendidos (Gráfico de Barras)
        llTopProdutosContainer.removeAllViews()

        val vendasPorProduto = vendas.groupBy { it.produtoNome }
            .mapValues { entry -> entry.value.sumOf { it.quantidade } }
            .toList()
            .sortedByDescending { it.second }

        if (vendasPorProduto.isEmpty()) {
            val tvVazio = TextView(this)
            tvVazio.text = "Nenhuma venda registrada ainda para exibir ranking."
            tvVazio.setTextColor(Color.parseColor("#757575"))
            tvVazio.textSize = 14f
            llTopProdutosContainer.addView(tvVazio)
        } else {
            val maxQtd = vendasPorProduto.first().second
            val topList = vendasPorProduto.take(5)

            for ((nome, qtd) in topList) {
                val tvProdutoInfo = TextView(this)
                tvProdutoInfo.text = "$nome - $qtd un."
                tvProdutoInfo.setTextColor(Color.parseColor("#333333"))
                tvProdutoInfo.textSize = 14f

                val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dpToPx(8)
                )
                params.setMargins(0, dpToPx(4), 0, dpToPx(12))
                progressBar.layoutParams = params
                progressBar.max = maxQtd
                progressBar.progress = qtd
                progressBar.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#9D5CFF"))

                llTopProdutosContainer.addView(tvProdutoInfo)
                llTopProdutosContainer.addView(progressBar)
            }
        }

        // 3. Alertas de Estoque Baixo
        llAlertasContainer.removeAllViews()
        val produtosBaixoEstoque = produtos.filter { (it.numero.toIntOrNull() ?: 0) <= 5 }

        if (produtosBaixoEstoque.isEmpty()) {
            val tvOk = TextView(this)
            tvOk.text = "• Todos os produtos possuem estoque suficiente."
            tvOk.setTextColor(Color.parseColor("#4CAF50"))
            tvOk.textSize = 14f
            llAlertasContainer.addView(tvOk)
        } else {
            for (prod in produtosBaixoEstoque) {
                val tvAlerta = TextView(this)
                tvAlerta.text = "• ${prod.nome} - Restam apenas ${prod.numero} un. em estoque!"
                tvAlerta.setTextColor(Color.parseColor("#E53935"))
                tvAlerta.textSize = 14f
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                params.setMargins(0, 0, 0, dpToPx(6))
                tvAlerta.layoutParams = params
                llAlertasContainer.addView(tvAlerta)
            }
        }
    }

    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return (dp * density).toInt()
    }
}
