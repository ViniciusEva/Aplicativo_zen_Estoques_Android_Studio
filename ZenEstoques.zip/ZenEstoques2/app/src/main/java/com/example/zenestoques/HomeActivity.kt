package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btnToggleMenu = findViewById<ImageButton>(R.id.btnToggleMenu)
        val llMenuContent = findViewById<LinearLayout>(R.id.llMenuContent)

        btnToggleMenu.setOnClickListener {
            if (llMenuContent.visibility == View.VISIBLE) {
                llMenuContent.visibility = View.GONE
            } else {
                llMenuContent.visibility = View.VISIBLE
            }
        }

        val btnCadastro = findViewById<MaterialButton>(R.id.btnIrCadastro)
        val btnConsultar = findViewById<MaterialButton>(R.id.btnConsultar)
        val btnRemover = findViewById<MaterialButton>(R.id.btnRemover)
        val btnEditar = findViewById<MaterialButton>(R.id.btnEditar)
        val btnAjudaMenu = findViewById<MaterialButton>(R.id.btnAjudaMenu)
        val btnHomeMenu = findViewById<MaterialButton>(R.id.btnHomeMenu)
        val btnDashboardMenu = findViewById<MaterialButton>(R.id.btnDashboardMenu)
        val btnProdutosMenu = findViewById<MaterialButton>(R.id.btnProdutosMenu)
        val btnVendasMenu = findViewById<MaterialButton>(R.id.btnVendasMenu)
        val ivPerfilMenuTop = findViewById<ImageView>(R.id.ivPerfilMenuTop)
        val ivPerfilMenu = findViewById<ImageView>(R.id.ivPerfilMenu)

        val abrirPerfil = {
            val intent = Intent(this, PerfilActivity::class.java)
            startActivity(intent)
        }

        ivPerfilMenuTop?.setOnClickListener { abrirPerfil() }
        ivPerfilMenu?.setOnClickListener { abrirPerfil() }

        btnHomeMenu.setOnClickListener {
            // Já estamos na Home
            llMenuContent.visibility = View.GONE
        }

        btnDashboardMenu.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
        }

        btnProdutosMenu.setOnClickListener {
            val intent = Intent(this, ProdutosActivity::class.java)
            startActivity(intent)
        }

        btnVendasMenu?.setOnClickListener {
            val intent = Intent(this, VendasActivity::class.java)
            startActivity(intent)
        }

        btnCadastro.setOnClickListener {
            Toast.makeText(this, "A abrir área de Registo de Produtos...", Toast.LENGTH_SHORT).show()
        }

        btnConsultar.setOnClickListener {
            val intent = Intent(this, ProdutosActivity::class.java)
            startActivity(intent)
        }

        btnRemover.setOnClickListener {
            Toast.makeText(this, "A abrir ecrã de remoção...", Toast.LENGTH_SHORT).show()
        }

        btnEditar.setOnClickListener {
            Toast.makeText(this, "A abrir ecrã de edição de produtos...", Toast.LENGTH_SHORT).show()
        }

        btnAjudaMenu.setOnClickListener {
            val intent = Intent(this, AjudaActivity::class.java)
            startActivity(intent)
        }
    }
}