package com.example.zenestoques

data class VendaModel(
    val id: Int = 0,
    val produtoNome: String,
    val quantidade: Int,
    val valorTotal: Double,
    val dataVenda: String
)
