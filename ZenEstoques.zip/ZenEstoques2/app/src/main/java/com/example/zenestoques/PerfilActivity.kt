package com.example.zenestoques

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class PerfilActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var sessionManager: SessionManager

    private lateinit var tvNomeHeader: TextView
    private lateinit var tvPerfilNome: TextView
    private lateinit var tvPerfilEmail: TextView
    private lateinit var tvPerfilTelefone: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        dbHelper = DatabaseHelper(this)
        sessionManager = SessionManager(this)

        tvNomeHeader = findViewById(R.id.tvNomeHeader)
        tvPerfilNome = findViewById(R.id.tvPerfilNome)
        tvPerfilEmail = findViewById(R.id.tvPerfilEmail)
        tvPerfilTelefone = findViewById(R.id.tvPerfilTelefone)

        val btnToggleMenu = findViewById<ImageButton>(R.id.btnToggleMenu)
        val llMenuContent = findViewById<LinearLayout>(R.id.llMenuContent)

        btnToggleMenu?.setOnClickListener {
            if (llMenuContent?.visibility == View.VISIBLE) {
                llMenuContent.visibility = View.GONE
            } else {
                llMenuContent?.visibility = View.VISIBLE
            }
        }

        val btnHomeMenu = findViewById<MaterialButton>(R.id.btnHomeMenu)
        val btnDashboardMenu = findViewById<MaterialButton>(R.id.btnDashboardMenu)
        val btnProdutosMenu = findViewById<MaterialButton>(R.id.btnProdutosMenu)
        val btnVendasMenu = findViewById<MaterialButton>(R.id.btnVendasMenu)
        val btnAjudaMenu = findViewById<MaterialButton>(R.id.btnAjudaMenu)
        val btnClosePerfil = findViewById<ImageButton>(R.id.btnClosePerfil)
        val btnEditarPerfil = findViewById<MaterialButton>(R.id.btnEditarPerfil)
        val btnSairPerfil = findViewById<MaterialButton>(R.id.btnSairPerfil)

        btnHomeMenu?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        btnDashboardMenu?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        btnProdutosMenu?.setOnClickListener {
            val intent = Intent(this, ProdutosActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnVendasMenu?.setOnClickListener {
            val intent = Intent(this, VendasActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnAjudaMenu?.setOnClickListener {
            val intent = Intent(this, AjudaActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Botão X para fechar a tela de Perfil
        btnClosePerfil?.setOnClickListener {
            finish()
        }

        btnEditarPerfil?.setOnClickListener {
            val intent = Intent(this, EditarPerfilActivity::class.java)
            startActivity(intent)
        }

        btnSairPerfil?.setOnClickListener {
            sessionManager.logout()
            Toast.makeText(this, "Sessão encerrada com sucesso!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        carregarDadosPerfil()
    }

    override fun onResume() {
        super.onResume()
        carregarDadosPerfil()
    }

    private fun carregarDadosPerfil() {
        val loggedEmail = sessionManager.getLoggedUserEmail()
        if (loggedEmail != null) {
            val user = dbHelper.getUserData(loggedEmail)
            if (user != null) {
                tvNomeHeader.text = if (user.nome.isNotEmpty()) user.nome else "Usuário"
                tvPerfilNome.text = "Nome: ${if (user.nome.isNotEmpty()) user.nome else "Marival"}"
                tvPerfilEmail.text = "Email: ${user.email}"
                tvPerfilTelefone.text = "Tel: ${if (user.telefone.isNotEmpty()) user.telefone else "(11) 92945-5768"}"
            } else {
                tvPerfilEmail.text = "Email: $loggedEmail"
            }
        }
    }
}