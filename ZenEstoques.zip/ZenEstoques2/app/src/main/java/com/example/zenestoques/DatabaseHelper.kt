package com.example.zenestoques

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_VERSION = 4
        private const val DATABASE_NAME = "ZenEstoquesDB.db"
        const val TABLE_USERS = "users"
        const val COLUMN_USER_ID = "user_id"
        const val COLUMN_USER_NOME = "user_nome"
        const val COLUMN_USER_EMAIL = "user_email"
        const val COLUMN_USER_TELEFONE = "user_telefone"
        const val COLUMN_USER_EMPRESA = "user_empresa"
        const val COLUMN_USER_PASSWORD = "user_password"
        const val COLUMN_USER_CPF = "user_cpf"

        // Constantes da Tabela Produtos
        const val TABLE_PRODUCTS = "products"
        const val COLUMN_PROD_ID = "prod_id"
        const val COLUMN_PROD_NOME = "prod_nome"
        const val COLUMN_PROD_NUMERO = "prod_numero"
        const val COLUMN_PROD_CODIGO = "prod_codigo"
        const val COLUMN_PROD_PRECO_COMPRA = "prod_preco_compra"
        const val COLUMN_PROD_PRECO_VENDA = "prod_preco_venda"

        // Constantes da Tabela Vendas
        const val TABLE_VENDAS = "vendas"
        const val COLUMN_VENDA_ID = "venda_id"
        const val COLUMN_VENDA_PROD_NOME = "venda_prod_nome"
        const val COLUMN_VENDA_QUANTIDADE = "venda_quantidade"
        const val COLUMN_VENDA_VALOR_TOTAL = "venda_valor_total"
        const val COLUMN_VENDA_DATA = "venda_data"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableUsers = ("CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_NOME + " TEXT,"
                + COLUMN_USER_EMAIL + " TEXT,"
                + COLUMN_USER_TELEFONE + " TEXT,"
                + COLUMN_USER_EMPRESA + " TEXT,"
                + COLUMN_USER_PASSWORD + " TEXT,"
                + COLUMN_USER_CPF + " TEXT" + ")")
        db.execSQL(createTableUsers)

        val createTableProducts = ("CREATE TABLE " + TABLE_PRODUCTS + "("
                + COLUMN_PROD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_PROD_NOME + " TEXT,"
                + COLUMN_PROD_NUMERO + " TEXT,"
                + COLUMN_PROD_CODIGO + " TEXT,"
                + COLUMN_PROD_PRECO_COMPRA + " REAL,"
                + COLUMN_PROD_PRECO_VENDA + " REAL" + ")")
        db.execSQL(createTableProducts)

        val createTableVendas = ("CREATE TABLE IF NOT EXISTS " + TABLE_VENDAS + "("
                + COLUMN_VENDA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_VENDA_PROD_NOME + " TEXT,"
                + COLUMN_VENDA_QUANTIDADE + " INTEGER,"
                + COLUMN_VENDA_VALOR_TOTAL + " REAL,"
                + COLUMN_VENDA_DATA + " TEXT" + ")")
        db.execSQL(createTableVendas)
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        val createTableVendas = ("CREATE TABLE IF NOT EXISTS " + TABLE_VENDAS + "("
                + COLUMN_VENDA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_VENDA_PROD_NOME + " TEXT,"
                + COLUMN_VENDA_QUANTIDADE + " INTEGER,"
                + COLUMN_VENDA_VALOR_TOTAL + " REAL,"
                + COLUMN_VENDA_DATA + " TEXT" + ")")
        db.execSQL(createTableVendas)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PRODUCTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_VENDAS")
        onCreate(db)
    }

    // Método para ser usado na tela de "Cadastre-se"
    fun addUser(
        email: String,
        pass: String,
        nome: String = "",
        telefone: String = "",
        empresa: String = "",
        cpf: String = ""
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_USER_NOME, nome)
        values.put(COLUMN_USER_EMAIL, email)
        values.put(COLUMN_USER_TELEFONE, telefone)
        values.put(COLUMN_USER_EMPRESA, empresa)
        values.put(COLUMN_USER_PASSWORD, pass)
        values.put(COLUMN_USER_CPF, cpf)
        val success = db.insert(TABLE_USERS, null, values)
        db.close()
        return success
    }

    // Buscar dados do usuário pelo e-mail
    fun getUserData(email: String): UserModel? {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_USERS WHERE $COLUMN_USER_EMAIL = ?", arrayOf(email))
        var user: UserModel? = null
        if (cursor.moveToFirst()) {
            val nome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NOME)) ?: ""
            val userEmail = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_EMAIL)) ?: ""
            val telefone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_TELEFONE)) ?: ""
            val empresa = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_EMPRESA)) ?: ""
            val cpf = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_CPF)) ?: ""
            user = UserModel(nome, userEmail, telefone, empresa, cpf)
        }
        cursor.close()
        db.close()
        return user
    }

    // Atualizar dados do perfil
    fun updateUserData(email: String, nome: String, telefone: String, cpf: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_USER_NOME, nome)
        values.put(COLUMN_USER_TELEFONE, telefone)
        values.put(COLUMN_USER_CPF, cpf)

        val rowsAffected = db.update(TABLE_USERS, values, "$COLUMN_USER_EMAIL = ?", arrayOf(email))
        db.close()
        return rowsAffected > 0
    }

    // Método para ser usado na tela de "Faça o Login"
    fun checkUser(email: String, pass: String): Boolean {
        val db = this.readableDatabase
        val columns = arrayOf(COLUMN_USER_ID)
        val selection = "$COLUMN_USER_EMAIL = ? AND $COLUMN_USER_PASSWORD = ?"
        val selectionArgs = arrayOf(email, pass)

        val cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null)
        val count = cursor.count
        cursor.close()
        db.close()
        return count > 0
    }

    // READ: Buscar todos os usuários para mostrar no Logcat
    fun getAllUsers(): List<String> {
        val userList = ArrayList<String>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_USERS", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID))
                val email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_EMAIL)) ?: ""
                val nome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NOME)) ?: ""
                userList.add("ID: $id | Nome: $nome | Email: $email")
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return userList
    }

    // UPDATE: Atualizar a senha de um usuário
    fun updateUser(id: Int, newPass: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_USER_PASSWORD, newPass)

        val rowsAffected = db.update(TABLE_USERS, values, "$COLUMN_USER_ID = ?", arrayOf(id.toString()))
        db.close()
        return rowsAffected > 0
    }

    // DELETE: Deletar um usuário
    fun deleteUser(id: Int): Boolean {
        val db = this.writableDatabase
        val rowsDeleted = db.delete(TABLE_USERS, "$COLUMN_USER_ID = ?", arrayOf(id.toString()))
        db.close()
        return rowsDeleted > 0
    }

    // ---------------------------------------------------------
    // CRUD DE PRODUTOS
    // ---------------------------------------------------------

    fun addProduct(nome: String, numero: String, codigo: String, precoCompra: Double, precoVenda: Double): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_PROD_NOME, nome)
        values.put(COLUMN_PROD_NUMERO, numero)
        values.put(COLUMN_PROD_CODIGO, codigo)
        values.put(COLUMN_PROD_PRECO_COMPRA, precoCompra)
        values.put(COLUMN_PROD_PRECO_VENDA, precoVenda)
        
        val success = db.insert(TABLE_PRODUCTS, null, values)
        db.close()
        return success
    }

    fun getAllProducts(): List<ProductModel> {
        val productList = ArrayList<ProductModel>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_PRODUCTS", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PROD_ID))
                val nome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PROD_NOME))
                val numero = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PROD_NUMERO))
                val codigo = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PROD_CODIGO))
                val precoCompra = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PROD_PRECO_COMPRA))
                val precoVenda = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PROD_PRECO_VENDA))

                productList.add(ProductModel(id, nome, numero, codigo, precoCompra, precoVenda))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return productList
    }

    fun updateProduct(id: Int, nome: String, numero: String, codigo: String, precoCompra: Double, precoVenda: Double): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_PROD_NOME, nome)
        values.put(COLUMN_PROD_NUMERO, numero)
        values.put(COLUMN_PROD_CODIGO, codigo)
        values.put(COLUMN_PROD_PRECO_COMPRA, precoCompra)
        values.put(COLUMN_PROD_PRECO_VENDA, precoVenda)

        val rowsAffected = db.update(TABLE_PRODUCTS, values, "$COLUMN_PROD_ID = ?", arrayOf(id.toString()))
        db.close()
        return rowsAffected > 0
    }

    fun deleteProduct(id: Int): Boolean {
        val db = this.writableDatabase
        val rowsDeleted = db.delete(TABLE_PRODUCTS, "$COLUMN_PROD_ID = ?", arrayOf(id.toString()))
        db.close()
        return rowsDeleted > 0
    }

    // ---------------------------------------------------------
    // CRUD DE VENDAS
    // ---------------------------------------------------------

    fun addVenda(produtoNome: String, quantidade: Int, valorTotal: Double, dataVenda: String): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_VENDA_PROD_NOME, produtoNome)
        values.put(COLUMN_VENDA_QUANTIDADE, quantidade)
        values.put(COLUMN_VENDA_VALOR_TOTAL, valorTotal)
        values.put(COLUMN_VENDA_DATA, dataVenda)

        val success = db.insert(TABLE_VENDAS, null, values)
        db.close()
        return success
    }

    fun getAllVendas(): List<VendaModel> {
        val vendas = ArrayList<VendaModel>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_VENDAS ORDER BY $COLUMN_VENDA_ID DESC", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VENDA_ID))
                val prodNome = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VENDA_PROD_NOME)) ?: ""
                val qtd = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_VENDA_QUANTIDADE))
                val total = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_VENDA_VALOR_TOTAL))
                val data = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VENDA_DATA)) ?: ""

                vendas.add(VendaModel(id, prodNome, qtd, total, data))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return vendas
    }

    fun deleteVenda(id: Int): Boolean {
        val db = this.writableDatabase
        val rowsDeleted = db.delete(TABLE_VENDAS, "$COLUMN_VENDA_ID = ?", arrayOf(id.toString()))
        db.close()
        return rowsDeleted > 0
    }
}
